import numpy as np
import math
from scipy.spatial.transform import Rotation 

def rot2eul(R):
    beta = -np.arcsin(R[2,0])
    alpha = np.arctan2(R[2,1]/np.cos(beta),R[2,2]/np.cos(beta))
    gamma = np.arctan2(R[1,0]/np.cos(beta),R[0,0]/np.cos(beta))
    return np.array((alpha, beta, gamma))

def calMat(d,theta,a,alfa):
    


    A = np.array([
        [0.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0, 0.0],
        ])
    
    B = np.array([
        [0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0],
        ])



    A[0][0]=math.cos(theta)
    A[0][1]=-math.sin(theta)*math.cos(alfa)
    A[0][2]=math.sin(theta)*math.sin(alfa)
    A[0][3]=a*math.cos(theta)

    A[1][0]=math.sin(theta)
    A[1][1]=math.cos(theta)*math.cos(alfa)
    A[1][2]=-math.cos(theta)*math.sin(alfa)
    A[1][3]=a*math.sin(theta)

    A[2][0]=0
    A[2][1]=math.sin(alfa)
    A[2][2]=math.cos(alfa)
    A[2][3]=d


    B[0][0]=A[0][0]
    B[0][1]=A[0][1]
    B[0][2]=A[0][2]

    B[1][0]=A[1][0]
    B[1][1]=A[1][1]
    B[1][2]=A[1][2]

    B[2][0]=A[2][0]
    B[2][1]=A[2][1]
    B[2][2]=A[2][2]
    
    ang = rot2eul(B)
    """angles = r.from_euler("zyx",degrees=True)"""



    print(A)
    print(ang)
    print("*******************")

"""DH parameters - meters - radians"""
calMat(0.265,0,0,-math.pi/2)
calMat(0,-math.pi/2,0.444,0)
calMat(0,0,0.11,-math.pi/2)
calMat(0.47,0,0,math.pi/2)
calMat(0,0,0.08,-math.pi/2)
calMat(0.101,math.pi,0,0)